import pandas as pd
import pickle
import os

from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression

df = pd.read_csv("dataset/student_data.csv")

X = df[['study_hours', 'attendance', 'assignments']]
y = df['score']

model = Pipeline([
    ('poly', PolynomialFeatures(degree=2)),
    ('linear', LinearRegression())
])

model.fit(X, y)

os.makedirs("model", exist_ok=True)

pickle.dump(model, open("model/poly_model.pkl", "wb"))

print("Polynomial model trained!")