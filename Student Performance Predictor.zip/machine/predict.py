import pickle
import pandas as pd

# Load model
model = pickle.load(open("model/model.pkl", "rb"))

study_hours = float(input("Enter Study Hours: "))
attendance = float(input("Enter Attendance (%): "))
assignments = float(input("Enter Assignment Score: "))

data = pd.DataFrame({
    'study_hours':[study_hours],
    'attendance':[attendance],
    'assignments':[assignments]
})

prediction = model.predict(data)

print("\nPredicted Exam Score:", round(prediction[0],2))