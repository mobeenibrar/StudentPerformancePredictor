from flask import Flask, render_template, request
import pandas as pd
import pickle

# Create Flask app
app = Flask(__name__)

# Load trained model
with open("model/model.pkl", "rb") as file:
    model = pickle.load(file)

# Home page
@app.route('/')
def home():
    return render_template('index.html')

# Prediction page
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get user inputs
        study_hours = float(request.form['study_hours'])
        attendance = float(request.form['attendance'])
        assignments = float(request.form['assignments'])

        # Create DataFrame
        data = pd.DataFrame({
            'study_hours': [study_hours],
            'attendance': [attendance],
            'assignments': [assignments]
        })

        # Predict score
        prediction = model.predict(data)[0]

        return render_template(
            'index.html',
            prediction=round(prediction, 2)
        )

    except Exception as e:
        return render_template(
            'index.html',
            prediction=f"Error: {str(e)}"
        )

# Run application
if __name__ == '__main__':
    app.run(debug=True)