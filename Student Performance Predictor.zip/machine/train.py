import pandas as pd
import pickle
import os

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Load dataset
df = pd.read_csv("dataset/student_data.csv")

# Features
X = df[['study_hours', 'attendance', 'assignments']]

# Target
y = df['score']

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Create model folder if it doesn't exist
os.makedirs("model", exist_ok=True)

# Save model
pickle.dump(model, open("model/model.pkl", "wb"))

print("Model trained successfully!")
from sklearn.metrics import r2_score

predictions = model.predict(X_test)

score = r2_score(y_test, predictions)

print("Accuracy:", round(score * 100,2), "%")